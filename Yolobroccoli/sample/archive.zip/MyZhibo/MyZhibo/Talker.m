//
//  Talker.m
//  MyZhibo
//
//  Created by everettjf on 16/9/7.
//  Copyright © 2016年 zhibo. All rights reserved.
//

#import "Talker.h"

@implementation Talker

+ (void)load{
    NSLog(@"talker load");
}

- (void)say:(NSString *)words{
    NSLog(@"original say = %@",words);
}

+ (NSString *)bundleId{
    NSLog(@"original bundle id");
    return @"com.everettjf.original";
}

@end
