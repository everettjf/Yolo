//
//  Talker.h
//  MyZhibo
//
//  Created by everettjf on 16/9/7.
//  Copyright © 2016年 zhibo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Talker : NSObject

+ (NSString*)bundleId;

- (void)say:(NSString*)words;

@end
