#!/usr/bin/env bash

AppPath=testapp/MyZhibo.app
DylibPath=testapp/libhook1.dylib
MobileProvisionPath=testapp/embedded.mobileprovision
CertificateName="iPhone Developer: FengZhu Zhu (ST362UP54D)"
BundleID=YPV49M8592.com.qiwei.performance
IpaPath=testapp/MyZhibo.ipa

rm $IpaPath
python ./../yolobroccoli.py -a "$AppPath" -d "$DylibPath" -p "$MobileProvisionPath" -c "$CertificateName" -b "$BundleID" -o "$IpaPath"
mobiledevice install_app $IpaPath
