//
//  hook1.m
//  hook1
//
//  Created by everettjf on 16/9/10.
//  Copyright (c) 2016年 __MyCompanyName__. All rights reserved.
//

#import "CaptainHook.h"

//CHDeclareClass(ALBBBundle);
//CHClassMethod0(NSString*, ALBBBundle, appBundleId)
//{
//    NSLog(@"chclassmethod ALBBBundle appBundleId");
//    return @"com.0x7d7d.futurechat";
//}
//
//
//CHDeclareClass(AliSecXDeviceInfo);
//CHClassMethod0(NSString*, AliSecXDeviceInfo, getBundleId)
//{
//    NSLog(@"chclassmethod AliSecXDeviceInfo getBundleId");
//    return @"com.0x7d7d.futurechat";
//}


CHDeclareClass(Talker);
CHMethod1(void, Talker, say, id, arg1)
{
    NSLog(@"in hook say");
    NSString * tmp = @"hello android!";
    CHSuper1(Talker, say, tmp);
}

CHClassMethod0(NSString*, Talker, bundleId)
{
    NSLog(@"in hook bundle id");
    return @"com.hook.hook1";
}

CHClassMethod0(void, Talker, load)
{
    NSLog(@"Talker +load in dylib hook");
}

__attribute__((constructor)) static void entry(){
    NSLog(@"Hello , my dylib ");
    
//    CHLoadLateClass(ALBBBundle);
//    CHHook0(ALBBBundle,appBundleId);
//    
//    CHLoadLateClass(AliSecXDeviceInfo);
//    CHHook0(AliSecXDeviceInfo,getBundleId);
    
    CHLoadLateClass(Talker);
    CHHook1(Talker, say);
    CHHook0(Talker, bundleId);
    CHHook0(Talker, load);
}
